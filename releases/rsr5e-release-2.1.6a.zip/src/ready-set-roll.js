import { HooksUtility } from "./utils/hooks.js";

HooksUtility.registerModuleHooks();